<!DOCTYPE html>

      <div class="templatemo-content-wrapper">
        <div class="templatemo-content">
          <ol class="breadcrumb">
            <li><a href="<?php echo site_url('admin_dashboard') ?>">Admin Panel</a></li>
          </ol>
          Wellcome
      <div class="clearfix"></div>

<!--       <footer class="col-sm-12 templatemo-footer">
        <div class="templatemo-copyright">
          <p>Copyright &copy; 2084 Your Company Name</p>
        </div>
      </footer> -->
    </div>

