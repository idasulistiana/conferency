
	<div id="body">
	<div class="clearfix"></div>
		<div class="section">
			<img src="<?php echo base_url();?>assets/images/logo_hotelsalak.png" class="img_hotelsalak">
			<p>
			</p>
			<span class="text_venue">
				The international conference will be held:<br/>
				On	: Monday-Tuesday, October 10-11, 2016<br/>
				Venue	: Salak Tower Hotel,<br/>
				Jl. Salak No. 38-40, Bogor 16121, Indonesia<br/>
				Telepon:(0251) 7565111
			</span>
		</div>
	</div>