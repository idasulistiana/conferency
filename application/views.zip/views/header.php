<meta name="title" content="International">
<meta name="title" content="Conference">
<meta name="title" content="Biomass">
<meta name="title" content="Bogor">
<meta name="title" content="2016">
<meta name="title" content="icb">
<meta name="title" content="icb bogor">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/OpenSans-Bold/OpenSans-Bold.ttf" type="text/css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery.dataTables.min.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style_admin.css" type="text/css">